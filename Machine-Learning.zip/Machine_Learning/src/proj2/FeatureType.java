package proj2;

public enum FeatureType {
    CATEGROICAL,
    CONTINUOUS;
}
