package proj3.recycled;

public enum FeatureType {
    CATEGROICAL,
    CONTINUOUS;
}
