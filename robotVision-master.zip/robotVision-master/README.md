Welcome to Josh and Brendan's git directory for Robot Vision 2019 
spring semester.
